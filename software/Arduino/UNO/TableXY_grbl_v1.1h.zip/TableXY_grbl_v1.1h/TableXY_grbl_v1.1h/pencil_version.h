/*
  gcode.h - rs274/ngc parser.
  Part of Grbl

  Copyright (c) 2011-2015 Sungeun K. Jeon
  Copyright (c) 2009-2011 Simen Svale Skogsrud
  
  Grbl is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Grbl is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with Grbl.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef pencil_version_h
#define pencil_version_h

#define GRBL_PENCIL_VERSION "0.102"

//Compilation Date
#define GRBL_BUILD_PENCIL_DAY   "07"    // Day
#define GRBL_BUILD_PENCIL_MONTH "04"    // Month
#define GRBL_BUILD_PENCIL_YEAR "2026"   // Year

#endif
